from setuptools import setup, find_packages

setup(
    install_requires=[
        "numpy",
        "python-dotenv",
        "flask",
        "flask-cors",
        "requests"
    ],
)
